// Config is put into a different package to prevent cyclic imports in case
// it is needed in several locations

package config

import "time"

type Config struct {
	Period         time.Duration `config:"period"`
	DTRURL         string        `config:"dtrurl"`
	KubeConfigPath string        `config:"kubeconfigPath"`
	DTRUserName    string        `config:"dtrusername"`
	DTRCredential  string        `config:"dtrcredential"`
	DTRDomainName  string        `config:"dtrdomainname"`
}

var DefaultConfig = Config{
	Period: 1 * time.Second,
}
