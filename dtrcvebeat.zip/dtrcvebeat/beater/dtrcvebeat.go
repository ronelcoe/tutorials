package beater

import (
	"context"
	"encoding/base64"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"
	"time"

	"github.com/elastic/beats/v7/libbeat/beat"
	"github.com/elastic/beats/v7/libbeat/common"
	"github.com/elastic/beats/v7/libbeat/logp"

	"github.com/ronelcoe/dtrcvebeat/config"

	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/clientcmd"
)

// dtrcvebeat configuration.
type dtrcvebeat struct {
	done   chan struct{}
	config config.Config
	client beat.Client
}

// New creates an instance of dtrcvebeat.
func New(b *beat.Beat, cfg *common.Config) (beat.Beater, error) {
	c := config.DefaultConfig
	if err := cfg.Unpack(&c); err != nil {
		return nil, fmt.Errorf("Error reading config file: %v", err)
	}

	bt := &dtrcvebeat{
		done:   make(chan struct{}),
		config: c,
	}
	return bt, nil
}

// Run starts dtrcvebeat.
func (bt *dtrcvebeat) Run(b *beat.Beat) error {
	logp.Info("dtrcvebeat is running! Hit CTRL-C to stop it.")

	var err error
	bt.client, err = b.Publisher.Connect()
	if err != nil {
		return err
	}

	config, _ := clientcmd.BuildConfigFromFlags("", bt.config.KubeConfigPath)
	// creates the clientset
	clientset, _ := kubernetes.NewForConfig(config)
	deployments, _ := clientset.AppsV1().Deployments("").List(context.TODO(), v1.ListOptions{})

	ticker := time.NewTicker(bt.config.Period)
	// counter := 1
	// for {
	// 	select {
	// 	case <-bt.done:
	// 		return nil
	// 	case <-ticker.C:
	// 	}

	// 	event := beat.Event{
	// 		Timestamp: time.Now(),
	// 		Fields: common.MapStr{
	// 			"type":    b.Info.Name,
	// 			"counter": counter,
	// 		},
	// 	}
	// 	bt.client.Publish(event)
	// 	logp.Info("Event sent")
	// 	counter++
	// }

	x := 0
	var namespace string
	var imageName string
	var version string
	for {
		select {
		case <-bt.done:
			return nil
		case <-ticker.C:
		}

		y := 0
		var dtrResp string
		containers := deployments.Items[x].Spec.Template.Spec.Containers
		for y < len(containers) {
			// fmt.Println(containers[y].Image)
			// namespace, imageName, version = parseImageName(containers[y].Image)
			dtrResp = callDTR(bt, containers[y].Image)
			y++
		}
		x++

		event := beat.Event{
			Timestamp: time.Now(),
			Fields: common.MapStr{
				"type":      b.Info.Name,
				"counter":   x,
				"namespace": namespace,
				"imageName": imageName,
				"version":   version,
				"dtrBody":   dtrResp,
			},
		}
		bt.client.Publish(event)
		logp.Info("Event sent")

		if x == len(deployments.Items) {
			return nil
		}
	}
}

// func parseImageName(bt *dtrcvebeat, image string) (string, string, string) {
// 	// fmt.Println(image)
// 	namespace := image[:strings.Index(image, bt.config.DTRDomainName+"/")]
// 	imageName := image[strings.Index(image, "/")+1 : strings.Index(image, ":")]
// 	imageVersion := image[strings.Index(image, ":")+1:]
// 	// fmt.Println(namespace, imageName, version)
// 	return namespace, imageName, imageVersion
// }

func callDTR(bt *dtrcvebeat, image string) string {
	// var namespace string
	// var imageName string
	// var imageVersion string

	// namespace, imageName, imageVersion = parseImageName(bt, image)

	namespace := image[:strings.Index(image, bt.config.DTRDomainName+"/")]
	imageName := image[strings.Index(image, "/")+1 : strings.Index(image, ":")]
	imageVersion := image[strings.Index(image, ":")+1:]

	// Customer ID
	customerKey := bt.config.DTRUserName
	// Customer secret
	customerSecret := bt.config.DTRCredential

	// Concatenate customer key and customer secret and use base64 to encode the concatenated string
	plainCredentials := customerKey + ":" + customerSecret
	base64Credentials := base64.StdEncoding.EncodeToString([]byte(plainCredentials))

	url := bt.config.DTRURL + "/" + namespace + "/" + imageName + "/" + imageVersion + "?scanstatus=true"
	method := "GET"

	payload := strings.NewReader(``)

	client := &http.Client{}
	req, err := http.NewRequest(method, url, payload)

	if err != nil {
		fmt.Println(err)
		return "encountered error on creating request"
	}
	// Add Authorization header
	req.Header.Add("Authorization", "Basic "+base64Credentials)
	req.Header.Add("Content-Type", "application/json")

	fmt.Println("Sending https request", req)
	// Send HTTP request
	res, err := client.Do(req)
	if err != nil {
		fmt.Println(err)
		return "encountered error on sending http request"
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		fmt.Println(err)
		return "encountered error on readall"
	}
	fmt.Println(string(body))
	return string(body)
}

// Stop stops dtrcvebeat.
func (bt *dtrcvebeat) Stop() {
	bt.client.Close()
	close(bt.done)
}
