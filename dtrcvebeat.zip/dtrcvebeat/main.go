package main

import (
	"os"

	"github.com/ronelcoe/dtrcvebeat/cmd"

	_ "github.com/ronelcoe/dtrcvebeat/include"
)

func main() {
	if err := cmd.RootCmd.Execute(); err != nil {
		os.Exit(1)
	}
}
